package stepdefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import framework.webPages.DarkskyHomePage;
import org.testng.Assert;

public class DarkskySD {

    private DarkskyHomePage homePage = new DarkskyHomePage();

    @Given("^I am on home page$")
    public void iAmOnHomePage() {
        Assert.assertEquals(SharedSD.getDriver().getTitle(), "Dark Sky - Broadway, New York, NY");
    }
    @When("^I click on DarkSkyAPI button on home screen$")
    public void darkSkyAPI () throws InterruptedException {
        homePage.clickOnDarkSkyAPI();
    }

    @When("^I click on SignUp button on bottom of the screen$")
    public void signUp() throws InterruptedException {
        homePage.clickOnSignUpButton();
    }

    @When("^I click on Register button on upper right hand corner of the screen$")
    public void register () throws InterruptedException {
        homePage.clickOnRegisterButton();
    }

    @Then("^I verify error message \"please fill out this field\"$")
    public void verifyErrorMessage () throws InterruptedException {
        String message = "Please fill out this field.";
        String realMessage = homePage.getEmailErrorMsg();
        Thread.sleep(2000);
        Assert.assertEquals(realMessage, message);
    }

    @Then("^I verify current temp is not greater or less then temps from daily timeline$")
    public void verifyCurrentTemperature () {
        homePage.verifyTemperature();
        Assert.assertTrue(homePage.result);
    }
    @When("^I expand todays timeline$")
    public void todaysTimeline () throws InterruptedException {
        homePage.scrollto();
        homePage.expandTimeLine();
    }
    @Then("^I verify lowest and highest temp is displayed correctly$")
    public void verifyTimeLine () {
        homePage.verifyTimeLineTemperature();
        Assert.assertTrue(homePage.result);
    }

    @Then("^I verify timeline is displayed with two hours incremented$")
    public void timeLine () {
        homePage.timelineT();

    }
}
